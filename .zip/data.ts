const feedData: any[] = [{
    id: 1,
    thumbnail: null,
    title: '7/11 스페인어 스터디',
    contents: '바쁜 현대인들이 모여서 느슨하게 스페인어를 공부합니다. - 매일 5개 단어 외우기',
    group: {
        name: '여행가자',
        category: '공부',
    },
},
    {
        id: 2,
        thumbnail: null,
        title: '[독서] 별의 계승자 1/5',
        contents: '별의 계승자 탐독하기 1.어디까지 읽었나요?',
        group: {
            name: '책읽자',
            category: '취미',
        },
    },
    {
        id: 3,
        thumbnail: null,
        title: '🚀알고리즘 | 배열',
        contents: '',
        group: {
            name: '알고스터디',
            category: '공부',
        },
    },
    {
        id: 4,
        thumbnail: null,
        title: '7/11 스페인어 스터디',
        contents: '바쁜 현대인들이 모여서 느슨하게 스페인어를 공부합니다. - 매일 5개 단어 외우기',
        group: {
            name: '여행가자',
            category: '공부',
        },
    },
];

export {
    feedData,
}
