import {LiHTMLElements} from 'react';

interface Props extends LiHTMLElements<HTMLLiElement> {
}

export function UserListItem({props}: Props) {
    return (
    )
};
